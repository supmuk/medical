<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class TourProgram extends Model {
    protected $table = 'tour_program_manager';
    protected $guarded = [];

}