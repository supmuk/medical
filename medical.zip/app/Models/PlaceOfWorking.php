<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PlaceOfWorking extends Model {
    protected $table = 'place_of_working';
    protected $guarded = [];

}