<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class StandardFareChart extends Model {
    protected $table = 'standard_fare_chart_manager';
    protected $guarded = [];

}