Inquiry from: {{ $name }}
<p> Email: {{ $email }} </p>
<p> Phone: {{ $phone }} </p>
<p> Subject: {{ $subject }} </p>
<p> Message: {{ $message1 }} </p>