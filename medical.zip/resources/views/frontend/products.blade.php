@extends('layouts.frontend.layout')
@section('content')
@endsection